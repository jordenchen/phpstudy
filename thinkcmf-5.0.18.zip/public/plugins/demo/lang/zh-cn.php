<?php

return ['plugin_demo_hello_world'=>'您好,插件!'];